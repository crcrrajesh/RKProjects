from distutils.core import setup

setup(
    name='nesterd',
    version='1.0.1',
    packages=[''],
    url='',
    license='PY',
    author='rajesh.kumar',
    author_email='',
    description='nesterdes'
)
